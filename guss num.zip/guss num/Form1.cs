﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp20
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {


        }
        int min = 100; int max = 999; int x = 0; int y = 9;
        private void label1_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            int rnd = r.Next(100, 999);
            textBox1.Text = rnd.ToString();
            MessageBox.Show("");
            x = (max + min) / 2;
            textBox2.Text = x.ToString();
            listBox1.Items.Add(textBox2.Text);
            while (x != rnd)
            {
                if (x < rnd) { min = x; x = (x + max) / 2; }
                if (x > rnd) { max = x; x = (x + min) / 2; }
                textBox2.Text = x.ToString();
                listBox1.Items.Add(textBox2.Text);
                y--;textBox3.Text = y.ToString();
                if (x == rnd) { textBox2.BackColor= Color.Red; }
            }
        }
    }
}
